# Maps model outputs to your app's mood categories
# You can expand/refine these rules anytime.

from dataclasses import dataclass
from typing import Tuple

# Standardized moods your UI expects
ALLOWED_MOODS = ["happy", "sad", "energetic", "chill", "romantic", "devotional", "motivation"]

@dataclass
class MoodDecision:
    mood: str
    confidence: float

def text_to_mood(label: str, score: float, text: str) -> MoodDecision:
    # label from transformers sentiment model is usually "POSITIVE" / "NEGATIVE"
    t = text.lower()

    # Quick keyword boosts (multilingual-ish hack)
    romantic_keys = ["romantic", "love", "pyaar", "ishq", "❤️", "दिल", "मोहब्बत"]
    energetic_keys = ["party", "gym", "dance", "pump", "energy", "energetic", "🔥"]
    chill_keys = ["lofi", "calm", "study", "focus", "relax", "chill", "peace"]
    sad_keys = ["sad", "down", "low", "cry", "breakup", "alone", "😭", " उदास "]
    happy_keys = ["happy", "joy", "excited", "great", "awesome", "😊", "खुश"]
    devotional_keys = ["devotional", "bhajan", "bhakti", "prayer", "spiritual", "meditation", "🙏", "भक्ति", "ध्यान"]
    motivation_keys = ["motivation", "inspire", "success", "goal", "achieve", "dream", "💪", "प्रेरणा", "लक्ष्य"]

    def any_in(keys): 
        return any(k in t for k in keys)

    # Strong keyword nudges override base sentiment
    if any_in(romantic_keys): 
        return MoodDecision("romantic", max(score, 0.85))
    if any_in(energetic_keys):
        return MoodDecision("energetic", max(score, 0.85))
    if any_in(chill_keys):
        return MoodDecision("chill", max(score, 0.85))
    if any_in(sad_keys):
        return MoodDecision("sad", max(score, 0.85))
    if any_in(happy_keys):
        return MoodDecision("happy", max(score, 0.85))
    if any_in(devotional_keys):
        return MoodDecision("devotional", max(score, 0.85))
    if any_in(motivation_keys):
        return MoodDecision("motivation", max(score, 0.85))

    # Sentiment fallback
    if label.upper() == "POSITIVE":
        # Decide between happy vs energetic using exclamation/tempo hints
        if "!" in t or "party" in t or "dance" in t or "gym" in t:
            return MoodDecision("energetic", score)
        return MoodDecision("happy", score)
    else:
        # Negative → sad or chill depending on tone
        if "tired" in t or "exhausted" in t or "study" in t or "focus" in t:
            return MoodDecision("chill", score)
        return MoodDecision("sad", score)
